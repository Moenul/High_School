<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Sliders</h3>&nbsp;&nbsp;<span>Manage Sliders Photo</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->
<div class="container">

    <div class="row">
        <div class="col-6">
            <table class="table table-dark table-hover mx-auto">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Action</th>
                    <th style="width:80px; text-align:center;">Delete</th>
                </tr>
                </thead>
                <tbody>

                <?php if($sliders->count()): ?>

                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($slider->id); ?>

                        </td>
                        <td>
                            <img class="action_field border border-secondary" width="130px" height="80px" src="<?php echo e($slider->photo ? $slider->photo->file : '/images/Empty_Images_Landscape.jpg'); ?>">
                        </td>
                        <td>
                            <?php if($slider->status == 1): ?>
                                <?php echo Form::open(['method'=>'PATCH', 'action'=> ['AdminSlidersController@update', $slider->id]]); ?>

                                <input type="hidden" name="status" value="0">
                                <div class='form-group'>
                                <?php echo Form::submit('Off', ['class'=>'btn btn-sm font-weight-bold btn-warning']); ?>

                                </div>
                                <?php echo Form::close(); ?>

                            <?php else: ?>
                                <?php echo Form::open(['method'=>'PATCH', 'action'=> ['AdminSlidersController@update', $slider->id]]); ?>

                                <input type="hidden" name="status" value="1">
                                <div class='form-group'>
                                <?php echo Form::submit('On', ['class'=>'btn btn-sm font-weight-bold btn-success']); ?>

                                </div>
                                <?php echo Form::close(); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                        <?php echo Form::open(['method'=>'DELETE', 'action'=> ['AdminSlidersController@destroy', $slider->id]]); ?>

                            <?php echo e(Form::button('<i class="fas fa-trash-alt text-danger"></i>', ['type' => 'submit', 'class' => 'btn btn-lg'] )); ?>

                        <?php echo Form::close(); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>

                </tbody>

            </table>
        </div>
        <div class="col-1"></div>

        <div class="col-4">
            <h5 class="text-center text-success">Add New Image</h5>
            <?php if($sliders->count() <= 4): ?>

                <?php echo Form::open(['method'=>'POST', 'action'=>'AdminSlidersController@store', 'files'=>true]); ?>

                <div class="mb-2 d-flex justify-content-center">
                    <img class="action_field border border-secondary" id="preview_img" width="200px" height="120px"  src="<?php echo e('/images/Empty_Images_Landscape.jpg'); ?>">
                </div>

                <div class="form-group">
                    <?php echo Form::label('photo_id', 'Image:'); ?>

                    <?php echo Form::file('photo_id', ['class'=>'form-file-control  border', 'id' => 'imgInp', 'required'=>'required'], null); ?>

                </div>
                <input type="hidden" name="status" value="1">
                <div class="form-group">
                    <?php echo Form::submit('Upload Image', ['class'=>'btn btn-success']); ?>

                </div>

                <?php echo Form::close(); ?>

            <?php endif; ?>
        </div>
    </div>


</div>

    <!-- start dashboard content -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/sliders/index.blade.php ENDPATH**/ ?>