

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Policy</h3>&nbsp;&nbsp;<span>Create Policy</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->

    <div class="container">

        <h5 class="text-center text-success">Create New Policy</h5>
        <?php echo Form::open(['method'=>'POST', 'action'=>'AdminPolicysController@store', 'files'=>true]); ?>

        <div class="form-group">
            <?php echo Form::label('name','Policy Name:'); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('title','Policy title:'); ?>

            <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('photo_id', 'Photo :'); ?>

            <?php echo Form::file('photo_id', ['id' => 'imgInp'], null); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('desc','Write Policy:'); ?>

            <?php echo Form::textarea('desc', null, ['class'=>'form-control ckeditor','rows'=>5]); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Create', ['class'=>'btn btn-success  float-right']); ?>

        </div>

        <?php echo Form::close(); ?>


    </div>
    <!-- end dashboard content -->

</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
       $('.ckeditor').ckeditor();
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/policys/create.blade.php ENDPATH**/ ?>