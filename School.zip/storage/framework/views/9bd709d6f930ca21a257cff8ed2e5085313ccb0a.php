

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Contact</h3>&nbsp;&nbsp;<span>Manage Contact Info</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->

    <div class="container">

    <?php if($contact): ?>


        <?php echo Form::model($contact, ['method'=>'PATCH', 'action'=> ['AdminContactsController@update', $contact->id], 'files'=>true]); ?>

        <div class="row">

            <div class="form-group col-3">
                <?php echo Form::label('phone_1','Phone Number:'); ?>

                <?php echo Form::text('phone_1', $contact->phone_1, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group col-3">
                <?php echo Form::label('phone_2','Second Phone Number:'); ?>

                <?php echo Form::text('phone_2', $contact->phone_2, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group col-3">
                <?php echo Form::label('facebook_link','Facebook Link:'); ?>

                <?php echo Form::text('facebook_link', $contact->facebook_link, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group col-3">
                <?php echo Form::label('whatsapp_link','Whatsapp Link:'); ?>

                <?php echo Form::text('whatsapp_link', $contact->whatsapp_link, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group col-3">
                <?php echo Form::label('youtube_link','Youtube Link:'); ?>

                <?php echo Form::text('youtube_link', $contact->youtube_link, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group col-3">
                <?php echo Form::label('address','Address:'); ?>

                <?php echo Form::text('address', $contact->address, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group col-3">
                <?php echo Form::label('address_link','Address Link:'); ?>

                <?php echo Form::text('address_link', $contact->address_link, ['class'=>'form-control']); ?>

            </div>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Update Contacts', ['class'=>'btn btn-primary float-right']); ?>

        </div>

        <?php echo Form::close(); ?>



    <?php endif; ?>

    </div>
    <!-- end dashboard content -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/contacts/edit.blade.php ENDPATH**/ ?>