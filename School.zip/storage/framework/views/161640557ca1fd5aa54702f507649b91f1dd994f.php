<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Contact</h3>&nbsp;&nbsp;<span>Manage Contact Info</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

 <!-- start dashboard content -->

 <div class="row">
    <?php if($about): ?>

    <div class="col-2"></div>
    <div class="col-6">
        <label for="">Logo:</label>
        <?php echo Form::model($about, ['method'=>'PATCH', 'action'=> ['AdminAboutsController@update', $about->id], 'files'=>true]); ?>


        <div class="mb-2 d-flex justify-content-center">
            <img class="action_field border border-secondary" id="preview_img" width="150px" height="150px" src="<?php echo e($about->photo ? $about->photo->file : '/images/Empty_Images.jpg'); ?>">
        </div>
        <div class="form-group">
            <?php echo Form::label('photo_id', 'Image:'); ?>

            <?php echo Form::file('photo_id', ['class'=>'form-file-control  border', 'id' => 'imgInp'], null); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('institute_name','Institute Name:'); ?>

            <?php echo Form::text('institute_name', $about->institute_name, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('institute_desc','Institute Description:'); ?>

            <?php echo Form::textarea('institute_desc', $about->institute_desc, ['class'=>'form-control','rows'=>5]); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('cover_id', 'Cover:'); ?>

            <?php echo Form::file('cover_id', ['class'=>'form-file-control  border'], null); ?>

        </div>

        <div class="mb-2 d-flex justify-content-center">
            <img class="second_action_field border border-secondary img-fluid" id="second_preview_img" width="1110px" height="60px" src="<?php echo e($about->nav ? $about->nav->file : '/images/Empty_Images_Landscape.jpg'); ?>">
        </div>
        <div class="form-group">
            <?php echo Form::label('nav_id', 'Top Nav Image:'); ?>

            <?php echo Form::file('nav_id', ['class'=>'form-file-control  border', 'id' => 'second_imgInp'], null); ?>

            <span class="d-block text-danger">Image size must be 1000px * 60px for Better Results </span>
        </div>

        <div class="form-group">
            <?php echo Form::label('tagline','TagLine:'); ?>

            <?php echo Form::text('tagline', $about->tagline, ['class'=>'form-control']); ?>

        </div>


        <div class="form-group">
            <?php echo Form::submit('Update Abouts', ['class'=>'btn btn-primary float-right']); ?>

        </div>

        <?php echo Form::close(); ?>

    </div>

    <?php endif; ?>
</div>


<!-- end dashboard content -->


</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script>


// Before Upload Preview Image

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $('#second_preview_img').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]); // convert to base64 string
        $('.second_action_field').show();
    }
}

$("#second_imgInp").change(function() {
    readURL(this);
});

// --------




</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/abouts/edit.blade.php ENDPATH**/ ?>