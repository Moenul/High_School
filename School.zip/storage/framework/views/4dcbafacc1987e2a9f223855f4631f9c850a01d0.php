

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Event</h3>&nbsp;&nbsp;<span>Edit Event</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->

    <div class="container">
        <?php if($event): ?>

        <div class="col-4 m-0">
            <?php echo Form::model($event, ['method'=>'PATCH', 'action'=> ['AdminEventsController@update', $event->id], 'files'=>true]); ?>

            <div class="form-group">
                <?php echo Form::label('title','Event Title:'); ?>

                <?php echo Form::text('title', $event->title, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('desc','Event Description:'); ?>

                <?php echo Form::textarea('desc', $event->desc, ['class'=>'form-control','rows'=>5]); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('date','Event Date:'); ?>

                <?php echo Form::date('date', $event->date, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('time','Event Time:'); ?>

                <?php echo Form::text('time', $event->time, ['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <a href="<?php echo e(url('admin/events')); ?>" class="btn btn-warning">Cancel</a>
                <?php echo Form::submit('Update Event', ['class'=>'btn btn-primary float-right']); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>

        <?php endif; ?>

    </div>
    <!-- end dashboard content -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/events/edit.blade.php ENDPATH**/ ?>