

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Contact</h3>&nbsp;&nbsp;<span>Manage Contact Info</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->
<div class="container">

    <?php if($contacts): ?>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row">
            <div class="form-group col-3">
                <label for=""><b>Phone Number:</b></label>
                <p><?php echo e($contact->phone_1); ?></p>
            </div>
            <div class="form-group col-3">
                <label for=""><b>Second Phone Number:</b></label>
                <p><?php echo e($contact->phone_2); ?></p>
            </div>
            <div class="form-group col-3">
                <label for=""><b>Facebook:</b></label>
                <p><?php echo e($contact->facebook_link); ?></p>
            </div>
            <div class="form-group col-3">
                <label for=""><b>Whatsapp:</b></label>
                <p><?php echo e($contact->whatsapp_link); ?></p>
            </div>
            <div class="form-group col-3">
                <label for=""><b>Youtube:</b></label>
                <p><?php echo e($contact->youtube_link); ?></p>
            </div>
            <div class="form-group col-3">
                <label for=""><b>Address:</b></label>
                <p><?php echo e($contact->address); ?></p>
            </div>
            <div class="form-group col-3">
                <label for=""><b>Address Link:</b></label>
                <p><?php echo e($contact->address_link); ?></p>
            </div>
        </div>

        <a class="btn btn-primary" href="<?php echo e(Route('admin.contacts.edit', $contact->id)); ?>">Edit Contacts</a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</div>

    <!-- start dashboard content -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>