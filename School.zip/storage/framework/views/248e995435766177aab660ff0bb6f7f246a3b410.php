<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Admissions</h3>&nbsp;&nbsp;<span>Manage Admissions</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->
<div class="container">

    <div class="row">
    <div class="col-12">
        <?php if($admissions->count()): ?>
        <table class="table table-dark table-hover mx-auto">
            <thead>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Student Name</th>
                <th>DOB</th>
                <th>Class</th>
                <th>Status</th>
                <th>Form</th>
                <th>View</th>
            </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($admission->id); ?></td>
                    <td>
                        <img class="action_field border border-secondary" width="60px" height="62px" src="<?php echo e($admission->photo ? $admission->photo->file : '/images/DummyProfile.jpg'); ?>">
                    </td>
                    <td><?php echo e($admission->student_name); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($admission->student_DOB)->format('d M Y')); ?></td>
                    <td><?php echo e($admission->admission_class); ?></td>
                    <td>
                        <?php if($admission->status == 0): ?>
                        <b class="text-center text-warning">Not Approved</b>
                        <?php else: ?>
                        <b class="text-center text-success">Approved</b>
                        <?php endif; ?>
                    </td>
                    <td><a href="<?php echo e(Route('admission.show', $admission->id)); ?>">View Form</a></td>
                    <td><a href="<?php echo e(Route('admin.admissions.show', $admission->id)); ?>">Show</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo $admissions->links(); ?>

        <?php endif; ?>


    </div>

    </div>


</div>

    <!-- start dashboard content -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/admissions/index.blade.php ENDPATH**/ ?>