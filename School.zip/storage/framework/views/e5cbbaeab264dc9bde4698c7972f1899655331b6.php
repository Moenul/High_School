<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Gallery</h3>&nbsp;&nbsp;<span>Manage Gallery Photo</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->
<div class="container">

    <div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <table class="table table-dark table-hover mx-auto">
            <thead>
            <tr>
                <th>Image</th>
                <th style="width:80px; text-align:center;">Delete</th>
            </tr>
            </thead>
            <tbody>

            <?php if($galleries->count()): ?>

                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <img class="action_field border border-secondary" width="180px" height="120px" src="<?php echo e($gallery->photo ? $gallery->photo->file : '/images/Empty_Images.jpg'); ?>">
                    </td>
                    <td>
                    <?php echo Form::open(['method'=>'DELETE', 'action'=> ['AdminGalleriesController@destroy', $gallery->id]]); ?>

                        <?php echo e(Form::button('<i class="fas fa-trash-alt text-danger"></i>', ['type' => 'submit', 'class' => 'btn btn-lg'] )); ?>

                    <?php echo Form::close(); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>

            </tbody>

            <?php if($galleries->count() <= 4): ?>

            <tr>
                <td colspan="2">
                <?php echo Form::open(['method'=>'POST', 'action'=>'AdminGalleriesController@store', 'files'=>true]); ?>

                <div class="mb-2 d-flex justify-content-center">
                    <img class="action_field border border-secondary" id="preview_img" width="140px" height="100px"  src="<?php echo e('/images/Empty_Images_Landscape.jpg'); ?>">

                    <div class="form-group">
                        <?php echo Form::label('photo_id', 'Image:'); ?>

                        <?php echo Form::file('photo_id', ['class'=>'form-file-control  border', 'id' => 'imgInp', 'required'=>'required'], null); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::submit('Upload Image', ['class'=>'btn btn-success  float-right']); ?>

                    </div>
                </div>

                <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php else: ?>

            <tr>
                <td colspan="2">
                    <p class="text-warning text-center"> Image upload limit is over, delete previous image to upload new image. </p>
                </td>
            </tr>

            <?php endif; ?>

        </table>


    </div>
    </div>




</div>

    <!-- start dashboard content -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/galleries/index.blade.php ENDPATH**/ ?>