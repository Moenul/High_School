<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header_content'); ?>

<div class="header_section">
	<div class="header_slider">
		<div class="slider" id="slider">
            <?php if($sliders): ?>
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slider_image"style="background-image: url('<?php echo e($slider->photo ? $slider->photo->file : '/images/Empty_Images_Landscape.jpg'); ?>');"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
		</div>
	</div>
	<div class="container">
        <?php if($about): ?>
            <p><?php echo e($about->institute_name); ?>

                <span><?php echo e($about->tagline); ?></span>
            </p>
        <?php endif; ?>
	</div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="updates_section">
	<div class="container">
		<div class="notice_section">
			<div class="section_title">নোটিশ</div>
			<div class="section_bar">

                <div id="data-wrapper">
                    <?php echo $__env->make('includes.notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

				<div class="load_more load-more-data"><i class="fa fa-refresh"></i> Load More ...</div>

                <!-- Data Loader -->
                <div class="auto-load text-center" style="display: none;">
                    <svg version="1.1" id="L9" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                        x="0px" y="0px" height="60" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                        <path fill="#000"
                            d="M73,50c0-12.7-10.3-23-23-23S27,37.3,27,50 M30.9,50c0-10.5,8.5-19.1,19.1-19.1S69.1,39.5,69.1,50">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="1s"
                                from="0 50 50" to="360 50 50" repeatCount="indefinite" />
                        </path>
                    </svg>
                </div>
                <!-- Data Loader -->


			</div>
		</div>
		<div class="event_section">
			<div class="section_title">ইভেন্ট</div>
			<div class="section_bar">

                <?php if($events->count()): ?>

                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if(\Carbon\Carbon::parse($event->date)->format('d M Y') >= \Carbon\Carbon::today()->format('d M Y')): ?>

                        <!-- event bar -->
                        <div class="event_bar">
                            <div class="event_date">
                                <div class="event_date_dot"></div>
                                <div class="event_date_dot"></div>
                                <div class="date_day"><?php echo e(\Carbon\Carbon::parse($event->date)->format('d')); ?></div>
                                <div class="date_month"><?php echo e(\Carbon\Carbon::parse($event->date)->format('M')); ?></div>
                                <div class="date_year"><?php echo e(\Carbon\Carbon::parse($event->date)->format('Y')); ?></div>
                            </div>
                            <div class="event_box">
                                <div class="event_title"><?php echo e($event->title); ?></div>
                                <div class="event_desc"><?php echo e($event->desc); ?></div>
                                <div class="event_time"><?php echo e($event->time); ?></div>
                            </div>
                        </div>
                        <!-- event bar -->

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="previous_event">
                        পূর্ববর্তী
                    </div>

                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if(\Carbon\Carbon::parse($event->date)->format('d M Y') < \Carbon\Carbon::today()->format('d M Y') ): ?>

                         <!-- previous event bar -->
                         <div class="event_bar previous_event_bar">
                            <div class="event_date">
                                <div class="event_date_dot"></div>
                                <div class="event_date_dot"></div>
                                <div class="date_day"><?php echo e(\Carbon\Carbon::parse($event->date)->format('d')); ?></div>
                                <div class="date_month"><?php echo e(\Carbon\Carbon::parse($event->date)->format('M')); ?></div>
                                <div class="date_year"><?php echo e(\Carbon\Carbon::parse($event->date)->format('Y')); ?></div>
                            </div>
                            <div class="event_box">
                                <div class="event_title"><?php echo e($event->title); ?></div>
                                <div class="event_desc"><?php echo e($event->desc); ?></div>
                                <div class="event_time"><?php echo e($event->time); ?></div>
                            </div>
                        </div>
                        <!-- previous event bar -->
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>

			</div>
		</div>
	</div>
</div>


<div class="gallery_section" id="gallery">
	<div class="container">
		<div class="section_name">গ্যালারি</div>
        <?php if($galleries): ?>
        <div class="gallery">
            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="gallery_item"><img src="<?php echo e($gallery->photo ? $gallery->photo->file : '/images/Empty_Images.jpg'); ?>"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
	</div>
</div>



<div class="about_section" id="about_us">
	<div class="container">
		<div class="section_name">আমাদের সমন্ধে</div>
        <?php if($about): ?>

		<div class="about_image_bar"><img src="<?php echo e($about->cover ? $about->cover->file : '/images/Empty_Images.jpg'); ?>"></div>
		<div class="about_desc_bar">
			<div class="desc_title"><?php echo e($about->institute_name); ?></div>
			<p><?php echo e($about->institute_desc); ?></p>
		</div>

        <?php endif; ?>
	</div>
</div>


<div class="president" id="president">
	<div class="container">
        <div class="section_name">সভাপতির বাণী</div>
		<div class="row">
			<?php if($speaches->where('person_type', '=', 'President')): ?>
                <?php $__currentLoopData = $speaches->where('person_type', '=', 'President'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <div class="president_img">
                            <img src="<?php echo e($person->photo ? $person->photo->file : '/images/DummyProfile.jpg'); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="name"><?php echo e($person->name); ?></div>
                        <div class="title"><?php echo e($person->title); ?></div>
                        <div class="desc">
                            <p><?php echo $person->desc; ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
		</div>
	</div>
</div>

<div class="institute_head" id="institute_head">
	<div class="container">
        <div class="section_name">প্রধান শিক্ষক এর বাণী</div>
		<div class="row">
            <?php if($speaches->where('person_type', '=', 'Institute Head')): ?>
                <?php $__currentLoopData = $speaches->where('person_type', '=', 'Institute Head'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <div class="institute_head_img">
                            <img src="<?php echo e($person->photo ? $person->photo->file : '/images/DummyProfile.jpg'); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="name"><?php echo e($person->name); ?></div>
                        <div class="title"><?php echo e($person->title); ?></div>
                        <div class="desc">
                            <p><?php echo $person->desc; ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
		</div>
	</div>
</div>



<div class="instructor_section" id="instructor">
	<div class="container">
		<div class="section_name">শিক্ষক মন্ডলী</div>
		<div class="instructors">
        <?php if($instructors->count()): ?>
            <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="instructor">
                    <div class="photo"><img src="<?php echo e($instructor->photo ? $instructor->photo->file : '/images/DummyProfile.jpg'); ?>"></div>
                    <div class="desc">
                        <div class="name"><?php echo e($instructor->name); ?></div>
                        <div class="title"><?php echo e($instructor->title); ?></div>
                        <div class="qualification"><?php echo e($instructor->qualification); ?></div>
                        <div class="phone">+88 <?php echo e($instructor->phone); ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p class="text-warning">No Data Found!</p>
        <?php endif; ?>
		</div>
	</div>
</div>


<div class="donor_member_section" id="school_committee">
	<div class="container">
		<div class="section_name">ম্যানেজিং কমিটি</div>
		<div class="donor_members">
        <?php if($members->count()): ?>
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="member">
                    <div class="photo"><img src="<?php echo e($member->photo ? $member->photo->file : '/images/DummyProfile.jpg'); ?>"></div>
                    <div class="name"><?php echo e($member->name); ?></div>
                    <div class="title">(<?php echo e($member->title); ?>)</div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p class="text-warning">No Data Found!</p>
        <?php endif; ?>
		</div>
	</div>
</div>


<div class="contact_section" id="contact">
	<div class="container">
		<div class="section_name">যোগাযোগ</div>

        <?php if($contact): ?>

		<div class="address_sction">
			<div class="option_title"><i class="fa-solid fa-phone-flip"></i> কল করুন </div>
			<div class="option_bar">
				<li><a href="tel:+880<?php echo e($contact->phone_1); ?>">+880 <?php echo e($contact->phone_1); ?></a></li>
				<li><a href="tel:+880<?php echo e($contact->phone_2); ?>">+880 <?php echo e($contact->phone_2); ?></a></li>
			</div>

			<div class="option_title"><i class="fa-solid fa-location-dot"></i> ঠিকানা : </div>
			<div class="option_bar">
				<li><?php echo e($contact->address); ?></li>
				<div class="location_bar">
					<div id="googleMap" style="width:100%; height: 100%;">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1821.4346813167701!2d91.10941800827581!3d24.070904540475286!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x375403bdb65ac59b%3A0xea30991b975c1391!2sSarail%20Sadar%20High%20School!5e0!3m2!1sen!2sbd!4v1694692619324!5m2!1sen!2sbd" width="100%" height="100%" style="border:2px solid grey; border-radius: 5px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
				</div>
			</div>
		</div>

        <?php endif; ?>

		<div class="mail_sction">
			<div class="sction_title">মেইল করুন :-</div>
			<div class="mail_inputs">
				<input type="email" name="email" id="" placeholder="আপনার ইমেইল লিখুন" required>
				<input type="text" name="subject" id="" placeholder="বিষয়">
				<textarea name="desc" id="" cols="20" rows="4" placeholder="এখানে লিখুন..."></textarea>
				<button class="btn btn-primary" type="submit" name="submit">Submit</button>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>

    var ENDPOINT = "<?php echo e(url('/home')); ?>";
    var page = 1;

    $(".load-more-data").click(function(){
        page++;
        infinteLoadMore(page);
    });

    /*------------------------------------------
    --------------------------------------------
    call infinteLoadMore()
    --------------------------------------------
    --------------------------------------------*/
    function infinteLoadMore(page) {
        $.ajax({
                url: ENDPOINT + "?page=" + page,
                datatype: "html",
                type: "get",
                beforeSend: function () {
                    $('.auto-load').show();
                }
            })
            .done(function (response) {
                if (response.html == '') {
                    $('.auto-load').html("We don't have more data to display :(");
                    return;
                }
                $('.auto-load').hide();
                $("#data-wrapper").append(response.html);
            })
            .fail(function (jqXHR, ajaxOptions, thrownError) {
                console.log('Server error occured');
            });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/home.blade.php ENDPATH**/ ?>