
<div class="side_nav">

    <a href="<?php echo e(url('/admin')); ?>"><li class="side_nav_item"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></li></a>

    <a href="<?php echo e(route('admin.admissions.index')); ?>"><li class="side_nav_item"><i class="fas fa-file-invoice"></i><span>Admission</span></li></a>
    
    <li class="side_nav_item"><i class="fas fa-school"></i><span>Academic</span>
        <ul class="side_dropdown">
            <a href="<?php echo e(route('admin.students.index')); ?>">All Students</a>
            <a href="<?php echo e(route('admin.classes.index')); ?>">Classes</a>
            <a href="<?php echo e(route('admin.sections.index')); ?>">Section</a>
            <a href="<?php echo e(route('admin.routines.index')); ?>">Class Routines</a>
            <a href="<?php echo e(route('admin.studentCosts.index')); ?>">Student Fee's</a>
        </ul>
    </li>

    <a href="<?php echo e(route('admin.notices.index')); ?>"><li class="side_nav_item"><i class="fas fa-volume-down"></i><span>Notice</span></li></a>
    <a href="<?php echo e(route('admin.events.index')); ?>"><li class="side_nav_item"><i class="fas fa-calendar-check"></i><span>Event</span></li></a>
    <a href="<?php echo e(route('admin.sliders.index')); ?>"><li class="side_nav_item"><i class="fas fa-camera-retro"></i><span>Slider</span></li></a>
    <a href="<?php echo e(route('admin.galleries.index')); ?>"><li class="side_nav_item"><i class="fas fa-image"></i><span>Gallery</span></li></a>

    

    

    
    <li class="side_nav_item"><i class="fas fa-puzzle-piece"></i><span>Widget</span>
        <ul class="side_dropdown">
            <a href="<?php echo e(route('admin.instructors.index')); ?>">Instructor</a>
            <a href="<?php echo e(route('admin.members.index')); ?>">Member</a>
            <a href="<?php echo e(route('admin.speaches.index')); ?>">Speach</a>
            <a href="<?php echo e(route('admin.contacts.index')); ?>">Contact Info</a>
            <a href="<?php echo e(route('admin.abouts.index')); ?>">About</a>
            <a href="<?php echo e(route('admin.policys.index')); ?>">Policy</a>
        </ul>
    </li>

    



    
    
    

</div>

<?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/includes/admin_sidenav.blade.php ENDPATH**/ ?>