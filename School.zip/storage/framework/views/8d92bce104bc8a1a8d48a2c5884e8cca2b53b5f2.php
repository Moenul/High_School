

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Routine</h3>&nbsp;&nbsp;<span>Create Routine</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->

    <div class="container">

        <h5 class="text-center text-success">Create New Routine</h5>
        <?php echo Form::open(['method'=>'POST', 'action'=>'AdminRoutinesController@store', 'files'=>true]); ?>

        <div class="form-group">
            <?php echo Form::label('class_id','Select Class:'); ?>

            <?php echo Form::select('class_id', $classes, null, ['class' => 'form-control', 'required'=>'required']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('routine','Make Routine:'); ?>

            <?php echo Form::textarea('routine', null, ['class'=>'form-control ckeditor','rows'=>5]); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Create', ['class'=>'btn btn-success  float-right']); ?>

        </div>

        <?php echo Form::close(); ?>


    </div>
    <!-- end dashboard content -->

</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
       $('.ckeditor').ckeditor();
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/routines/create.blade.php ENDPATH**/ ?>