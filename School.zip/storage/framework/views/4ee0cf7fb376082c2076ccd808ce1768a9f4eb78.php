

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Instructor</h3>&nbsp;&nbsp;<span>Manage Instructors</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->
<div class="container">

    <div class="row">
    <div class="col-8">
        <table class="table table-dark table-hover mx-auto">
            <thead>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Title</th>
                <th>Edit</th>
                <th style="width:80px; text-align:center;">Delete</th>
            </tr>
            </thead>
            <tbody>

            <?php if($instructors->count()): ?>

                <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($instructor->id); ?></td>
                    <td>
                        <img class="action_field border border-secondary" width="60px" height="62px" src="<?php echo e($instructor->photo ? $instructor->photo->file : '/images/DummyProfile.jpg'); ?>">
                    </td>
                    <td><?php echo e($instructor->name); ?></td>
                    <td><?php echo e($instructor->title); ?></td>
                    <td style="width:80px; text-align:center; font-size: 20px;"><a href="<?php echo e(Route('admin.instructors.edit', $instructor->id)); ?>"><i class="far fa-edit text-warning"></i></a></td>
                    <td>
                    <?php echo Form::open(['method'=>'DELETE', 'action'=> ['AdminInstructorsController@destroy', $instructor->id]]); ?>

                        <?php echo e(Form::button('<i class="fas fa-trash-alt text-danger"></i>', ['type' => 'submit', 'class' => 'btn btn-lg'] )); ?>

                    <?php echo Form::close(); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>

            </tbody>
        </table>

    </div>

    <div class="col-4">
        <h5 class="text-center text-success">Create New Instructor</h5>
        <?php echo Form::open(['method'=>'POST', 'action'=>'AdminInstructorsController@store', 'files'=>true]); ?>

        <div class="mb-2 d-flex justify-content-center">
            <img class="action_field border border-secondary" id="preview_img" width="100px" height="108px"  src="<?php echo e('/images/DummyProfile.jpg'); ?>">
        </div>
        <div class="form-group">
            <?php echo Form::label('photo_id', 'Image:'); ?>

            <?php echo Form::file('photo_id', ['id' => 'imgInp'], null); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('name','Name:'); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('title','Title:'); ?>

            <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('qualification','Qualification:'); ?>

            <?php echo Form::text('qualification', null, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('phone','Phone No.:'); ?>

            <?php echo Form::text('phone', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Submit', ['class'=>'btn btn-success  float-right']); ?>

        </div>

        <?php echo Form::close(); ?>

    </div>

    </div>


</div>

    <!-- start dashboard content -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/instructors/index.blade.php ENDPATH**/ ?>