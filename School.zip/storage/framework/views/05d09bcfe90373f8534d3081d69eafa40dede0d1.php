
<?php if($notices->count()): ?>
<?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- notice bar -->
<div class="notice_bar">
    <div class="image_box"><iconify-icon icon="bxs:file-pdf"></iconify-icon></div>
    <div class="notice_box">
        <div class="notice_title"><?php echo e($notice->title); ?></div>
        <div class="notice_date"><?php echo e(\Carbon\Carbon::parse($notice->created_at)->format('d M Y')); ?></div>
        <div class="notice_download"><a href="<?php echo e(action('DownloadsController@download', ['id'=> $notice->pdf_id ])); ?>">Download</a></div>
    </div>
</div>
<!-- notice bar -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="d-flex justify-content-center">
    
</div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/includes/notice.blade.php ENDPATH**/ ?>