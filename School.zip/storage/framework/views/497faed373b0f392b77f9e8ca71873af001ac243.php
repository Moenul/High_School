<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<div class="admission_section">
    <div class="container">
        <h1>শিক্ষার্থী তথ্য</h1>
        <div class="container mb-5">
            <div class="row">
                <h5>শ্রেণী নির্বাচন করুন :-</h5>
                <?php if($classes): ?>
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(action('StudentsController@index', ['class_id'=> $class->id])); ?>" class="btn btn-info m-1"><?php echo e($class->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="container">
            <?php if($students): ?>
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6 text-center mb-2">
                    <span class="d-block"><b>শিক্ষার্থী সংখ্যা :</b> <?php echo e($students->count()); ?> জন</span>
                    <span class="d-block"><b>ছাত্র সংখ্যা :</b> <?php echo e($students->where('student_gender','=','ছেলে')->count()); ?> জন</span>
                    <span class="d-block"><b>ছাত্রী সংখ্যা :</b> <?php echo e($students->where('student_gender','=','মেয়ে')->count()); ?> জন</span>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <table class="table table-sm">
                        <thead>
                          <tr>
                            <th scope="col">রোল</th>
                            <th scope="col">নাম</th>
                            <th scope="col">লিঙ্গ</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo $student->student_roll; ?></th>
                                    <td><?php echo $student->student_name; ?></td>
                                    <td>(<?php echo $student->student_gender; ?>)</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

        </div>

    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/students/index.blade.php ENDPATH**/ ?>