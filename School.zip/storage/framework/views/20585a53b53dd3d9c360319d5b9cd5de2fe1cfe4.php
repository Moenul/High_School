

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Routine</h3>&nbsp;&nbsp;<span>Manage Routines</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->
<div class="container">

    <div class="row">
    <div class="col-8">

        <table class="table table-dark">
            <thead>
            <tr>
                <th>Class</th>
                <th>Desc</th>
                <th>Edit</th>
                <th style="width:80px; text-align:center;">Delete</th>
            </tr>
            </thead>
            <tbody>
                <?php if($routines->count()): ?>
                    <?php $__currentLoopData = $routines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $routine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($routine->class->name); ?></td>
                            <td><?php echo e(\Illuminate\Support\Str::limit($routine->routine, 30, '...')); ?></td>
                            <td style="width:80px; text-align:center; font-size: 20px;"><a href="<?php echo e(Route('admin.routines.edit', $routine->id)); ?>"><i class="far fa-edit text-warning"></i></a></td>
                            <td>
                            <?php echo Form::open(['method'=>'DELETE', 'action'=> ['AdminRoutinesController@destroy', $routine->id]]); ?>

                                <?php echo e(Form::button('<i class="fas fa-trash-alt text-danger"></i>', ['type' => 'submit', 'class' => 'btn btn-lg'] )); ?>

                            <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>


    </div>

    <div class="col-4">
        <a href="<?php echo e(Route('admin.routines.create')); ?>" class="btn btn-success">Create New Routine</a>
    </div>

    </div>



</div>

    <!-- start dashboard content -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/routines/index.blade.php ENDPATH**/ ?>