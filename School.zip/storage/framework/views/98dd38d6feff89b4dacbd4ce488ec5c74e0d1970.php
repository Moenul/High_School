

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Policy</h3>&nbsp;&nbsp;<span>Manage Policy Info</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

 <!-- start dashboard content -->

 <div class="row">
    <?php if($policy): ?>

    <div class="col-12">
        <?php echo Form::model($policy, ['method'=>'PATCH', 'action'=> ['AdminPolicysController@update', $policy->id], 'files'=>true]); ?>


        <div class="form-group">
            <?php echo Form::label('name','Policy Name:'); ?>

            <?php echo Form::text('name', $policy->name, ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('title','Policy title:'); ?>

            <?php echo Form::text('title', $policy->title, ['class'=>'form-control']); ?>

        </div>

        <div class="mb-2 d-flex justify-content-center">
            <img class="action_field border border-secondary" id="preview_img" width="150px" height="150px" src="<?php echo e($policy->photo ? $policy->photo->file : '/images/Empty_Images.jpg'); ?>">
        </div>
        <div class="form-group">
            <?php echo Form::label('photo_id', 'Image:'); ?>

            <?php echo Form::file('photo_id', ['id' => 'imgInp'], null); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('desc','Policy Description:'); ?>

            <?php echo Form::textarea('desc', $policy->desc, ['class'=>'form-control  ckeditor','rows'=>5]); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Update Policy', ['class'=>'btn btn-primary float-right']); ?>

        </div>

        <?php echo Form::close(); ?>

    </div>

    <?php endif; ?>
</div>


<!-- end dashboard content -->


</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
       $('.ckeditor').ckeditor();
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/policys/edit.blade.php ENDPATH**/ ?>