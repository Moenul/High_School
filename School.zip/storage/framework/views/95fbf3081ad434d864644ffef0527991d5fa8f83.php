

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Welcome</h3>&nbsp;&nbsp;<span>Sub Heading</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->

        <a href="<?php echo e(route('admin.students.index')); ?>">
        <div class="panel user_panel">
            <div class="panel_icon"><i class="fas fa-user-graduate"></i></div>
            <div class="panel_content">
                <h5>Total Students</h5>
                <span>
                    <?php echo e(App\Models\Student::count()); ?>

                </span>
            </div>
        </div>
        </a>

        <a href="<?php echo e(route('admin.events.index')); ?>">
        <div class="panel post_panel">
            <div class="panel_icon"><i class="fas fa-calendar-check"></i></div>
            <div class="panel_content">
                <h5>Total Event</h5>
                <span><?php echo e(App\Models\Event::count()); ?></span>
            </div>
        </div>
        </a>

        <a href="<?php echo e(route('admin.notices.index')); ?>">
        <div class="panel comment_panel">
            <div class="panel_icon"><i class="fas fa-volume-down"></i></div>
            <div class="panel_content">
                <h5>Total Notice</h5>
                <span><?php echo e(App\Models\Notice::count()); ?></span>
            </div>
        </div>
        </a>

        <a href="<?php echo e(route('admin.instructors.index')); ?>">
        <div class="panel category_panel">
            <div class="panel_icon"><i class="fas fa-chalkboard-teacher"></i></div>
            <div class="panel_content">
                <h5>Total Instructor</h5>
                <span><?php echo e(App\Models\Instructor::count()); ?></span>
            </div>
        </div>
        </a>

    <!-- end dashboard content -->
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/index.blade.php ENDPATH**/ ?>