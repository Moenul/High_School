
<div class="scroll_to_top" onclick="topFunction()" id="myBtn">
	<iconify-icon icon="icon-park-outline:to-top"></iconify-icon>
</div>
<div class="footer">
	<div class="container">
		<div class="row footer_condition">
            <?php if(App\Models\Policy::all()): ?>
                <?php $__currentLoopData = App\Models\Policy::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6"><a href="<?php echo e(action('InformationsController@index', ['id'=> $policy->id])); ?>"> <i class="fas fa-caret-right"></i><?php echo e($policy->name); ?></a></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
			<div class="col-md-12 copyright">&copy; All Rights Reserved</div>
			<div class="col-md-12 credit">Design and Develoed credit gose to <a href="http://" target="_blank">MOENUL ISLAM</a></div>
		</div>
	</div>
</div>
<!-- end footer -->
<?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/includes/footer.blade.php ENDPATH**/ ?>