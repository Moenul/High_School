

<?php $__env->startSection('navigation'); ?>
    <?php echo $__env->make('includes.admin_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('side_nav'); ?>
    <?php echo $__env->make('includes.admin_sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>



<div class="content_section">
    <!-- start header -->
    <div class="header">
        <h3>Upgrade Student</h3>&nbsp;&nbsp;<span>Manage Upgrade</span>
        <a href="<?php echo e(url('../')); ?>"><i class="fas fa-home"></i>Home</a>
        <hr>
    </div>
    <!-- end header -->

    <!-- start dashboard content -->
<div class="container">


    <?php if($student): ?>

    <div class="form_section">
        <?php echo Form::model($student, ['method'=>'PATCH', 'action'=> ['AdminUpgradesController@update', $student->id], 'files'=>true]); ?>

        <div class="personal_info info_bar">
            <div class="row">
                <div class="col-8">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <?php echo Form::label('student_name','শিক্ষার্থীর নাম :'); ?>

                            <span class="d-block"><?php echo e($student->student_name); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <?php echo Form::label('student_name_en','শিক্ষার্থীর নাম ইংরেজি :'); ?>

                            <span class="d-block"><?php echo e($student->student_name_en); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <?php echo Form::label('student_DOB','জন্ম তারিখ :'); ?>

                            <span class="d-block"><?php echo e($student->student_DOB); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <?php echo Form::label('student_birth_reg','জন্ম নিবন্ধন নম্বর :'); ?>

                            <span class="d-block"><?php echo e($student->student_birth_reg); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <?php echo Form::label('student_birth_reg','লিঙ্গ :'); ?>

                            <span class="d-block"><?php echo e($student->student_gender); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <?php echo Form::label('student_birth_reg','পিতার নাম :'); ?>

                            <span class="d-block"><?php echo e($student->fathers_name); ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="mb-2 d-flex justify-content-center">
                        <img class="border border-secondary" width="130px" height="140px" src="<?php echo e($student->photo ? $student->photo->file : '/images/DummyProfile.jpg'); ?>">
                    </div>
                </div>
            </div>
        </div>


        <div class="additional_info info_bar">
            <div class="row">
                <input type="hidden" name="redirect_class" value="<?php echo e($student->class_id); ?>">
                <div class="form-group col-md-4">
                    <label for="name">অধ্যয়নরত শ্রেণি :</label>
                    <?php echo Form::select('class_id', $classes, $student->class_id, ['class' => 'form-control', 'required'=>'required']); ?>

                </div>
                <div class="form-group col-md-4">
                    <?php echo Form::label('student_section','শাখা :'); ?>

                    <?php echo Form::select('student_section', [null => ' প্রযোজ্য নয়'] + $sections, $student->student_section, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group col-md-4">
                    <?php echo Form::label('student_roll','রোল :'); ?>

                    <?php echo Form::text('student_roll', $student->student_roll, ['class'=>'form-control', 'placeholder'=>'রোল', 'required'=>'required']); ?>

                </div>
            </div>
        </div>

        <div class="form-group float-right">
            <?php echo Form::submit('Update Student', ['class'=>' m-4 btn btn-success submit_form_active']); ?>

        </div>

        <?php echo Form::close(); ?>

    </div>

    <?php endif; ?>

</div>

    <!-- start dashboard content -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/admin/upgrades/edit.blade.php ENDPATH**/ ?>