<!doctype html>
	<html lang="en" style="scroll-behavior: smooth; overflow-y: scroll;"></html>
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<title>School</title>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(URL::asset('images/favicon-16x16.png')); ?>">
</head>
<body>


<?php echo $__env->yieldContent('navigation'); ?>



<?php echo $__env->yieldContent('header_content'); ?>



<?php echo $__env->yieldContent('content'); ?>



<?php echo $__env->yieldContent('footer'); ?>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->

<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>

<script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>

<!-- Setup and start animation! -->
<script>


</script>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\Laravel_Project\School\School\resources\views/layouts/app.blade.php ENDPATH**/ ?>