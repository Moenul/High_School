
<nav class="navigation">
	<div class="dropdown_btn"><i class="fas fa-bars"></i></div>

	<div class="nav_bar">
		<li class="nav_item notification"><i class="far fa-bell"><span>4</span></i>
			<div class="dropdown">
				<div class="dropdown_title">Notification</div>
				<a href="">
					<div class="logo_bar"><img src=""></div>
					<div class="detail_bar">
						<div class="date">15 Dec 2023</div>
						<div class="desc">Notification description will be show here</div>
					</div>
				</a>
			</div>
		</li>


		<li class="nav_item message"><i class="far fa-envelope"><span>12</span></i>
			<div class="dropdown">
				<div class="dropdown_title">Message</div>
				<a href="">
					<div class="logo_bar"><img src=""></div>
					<div class="detail_bar">
						<div class="desc">Message description will be show here</div>
						<div class="info">
							<div class="name">Person Name</div>
							<div class="time">2h ago</div>
						</div>
					</div>
				</a>
			</div>
		</li>

		<li class="nav_item profile"><i class="far fa-profile"> <img src="\FrontEnd\Madrasah\images\DummyProfile.jpg"></i>
			<div class="dropdown">
				<div class="dropdown_title">Profile</div>
				<a href="">Profile</a>
				<a href="{{ route('logout') }}">Log Out</a>
			</div>
		</li>

	</div>


</nav>
